import './App.css';

import PersonDefaultDemo from './Components/DefaultProp'

import ArrayProps from './Components/ArrayAsProps'


// import ParentSampleRenderProps from './Components/RenderPropDemo'

import GrandParent from './Components/Live';

function App() {
  return (
    // Default Prop - Class Componet with Props
    // <div >
    //   <PersonDefaultDemo></PersonDefaultDemo>
    //   <PersonDefaultDemo name="Abhishek Pujara" gender="Male"></PersonDefaultDemo>
    //   <PersonDefaultDemo name="Nidhi Pujara" gender="Female"></PersonDefaultDemo>
    //   <PersonDefaultDemo name="Jay Poojara" gender="Male"></PersonDefaultDemo>
    // </div>

    // Array as Props
    // <ArrayProps></ArrayProps>


    // Render Props
    // <ParentSampleRenderProps/>
    
  );
}

export default App;
